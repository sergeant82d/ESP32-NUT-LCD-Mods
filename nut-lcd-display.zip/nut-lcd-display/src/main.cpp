// ESP32-NUT LCD Mirror
// -----------------------------------------------------------------------
// Runs on a SEPARATE board from the esp32-nut UPS bridge: the Elecrow
// CrowPanel Advance 2.4" ESP32-S3 HMI display. It polls esp32-nut's
// existing read-only JSON endpoints over Wi-Fi (no changes to the
// esp32-nut firmware are needed) and mirrors the "UPS Telemetry" web
// dashboard on the 320x240 screen.
//
// Endpoints used (see esp32-nut: src/network/web_config_server.cpp):
//   GET /api/ups-vars      -> ups.status, battery.charge, ups.load,
//                              battery.runtime, ups.realpower, ...
//   GET /api/system-status -> wifi.status, ups.status (model name)
//
// Libraries: LovyanGFX, lvgl (8.3.x), ArduinoJson (^7.0.0)
// -----------------------------------------------------------------------

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <lvgl.h>
#include <math.h>
#include <esp_heap_caps.h>

#include "lgfx_config.h"

// ---------------------------------------------------------------------
// User configuration - edit these for your network / esp32-nut device
// ---------------------------------------------------------------------
static const char *WIFI_SSID = "YOUR_WIFI_SSID";
static const char *WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// IP address (or hostname, if you set one up on your router/DNS) of the
// esp32-nut device. Find it on the esp32-nut web UI or your router's
// client list. esp32-nut does not currently advertise mDNS, so a
// plain "esp32-nut.local" will not resolve unless you add that
// yourself.
static const char *NUT_HOST = "192.168.1.50";

static const uint32_t POLL_INTERVAL_MS = 2000;         // /api/ups-vars
static const uint32_t STATUS_POLL_INTERVAL_MS = 10000; // /api/system-status
static const uint32_t WIFI_RETRY_INTERVAL_MS = 5000;
static const uint32_t HTTP_TIMEOUT_MS = 3000;

// ---------------------------------------------------------------------
// Theme - colors lifted from esp32-nut's web dashboard (bundle.css)
// ---------------------------------------------------------------------
#define COL_BG lv_color_hex(0x06090E)
#define COL_CARD_BG lv_color_hex(0x0B121C)
#define COL_BORDER lv_color_hex(0x1B2A3A)
#define COL_CYAN lv_color_hex(0x00F0FF)
#define COL_GREEN lv_color_hex(0x00FF9D)
#define COL_AMBER lv_color_hex(0xFFB800)
#define COL_RED lv_color_hex(0xFF3366)
#define COL_LABEL lv_color_hex(0x8A9BB3)
#define COL_TEXT lv_color_hex(0xE0E6ED)

// NOTE ON FONTS: the web UI uses "Orbitron" / "Share Tech Mono". LVGL
// ships only the Montserrat family by default, so this sketch uses
// that instead to guarantee it compiles out of the box. If you want
// the exact web look, run your chosen font through LVGL's online font
// converter (https://lvgl.io/tools/fontconverter) and swap the
// lv_font_montserrat_* references below for your generated font.

// ---------------------------------------------------------------------
// Display + touch driver instance (see lgfx_config.h)
// ---------------------------------------------------------------------
LGFX gfx;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t *lv_buf1 = nullptr;
static lv_color_t *lv_buf2 = nullptr;

static void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t w = area->x2 - area->x1 + 1;
  uint32_t h = area->y2 - area->y1 + 1;

  gfx.startWrite();
  gfx.setAddrWindow(area->x1, area->y1, w, h);
  gfx.writePixels((lgfx::rgb565_t *)&color_p->full, w * h);
  gfx.endWrite();

  lv_disp_flush_ready(disp);
}

static volatile bool touchForceRefresh = false;
static bool lastTouchState = false;

static void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data) {
  uint16_t touchX, touchY;
  bool touched = gfx.getTouch(&touchX, &touchY);
  if (touched) {
    data->state = LV_INDEV_STATE_PR;
    data->point.x = LCD_H_RES - touchX;
    data->point.y = touchY;
    if (!lastTouchState) touchForceRefresh = true; // tap = refresh now
  } else {
    data->state = LV_INDEV_STATE_REL;
  }
  lastTouchState = touched;
}

// ---------------------------------------------------------------------
// UI widgets
// ---------------------------------------------------------------------
struct StatCard {
  lv_obj_t *box;
  lv_obj_t *value;
};

static lv_style_t style_card;
static lv_obj_t *dot_live;
static lv_obj_t *dot_wifi;
static lv_obj_t *dot_ups;
static lv_obj_t *lbl_wifi;
static lv_obj_t *lbl_ups;
static lv_obj_t *lbl_status_value;
static StatCard card_batt, card_load, card_runtime, card_power;

static void init_styles() {
  lv_style_init(&style_card);
  lv_style_set_bg_color(&style_card, COL_CARD_BG);
  lv_style_set_bg_opa(&style_card, LV_OPA_COVER);
  lv_style_set_border_color(&style_card, COL_BORDER);
  lv_style_set_border_width(&style_card, 1);
  lv_style_set_radius(&style_card, 6);
  lv_style_set_pad_all(&style_card, 4);
}

static lv_obj_t *make_dot(lv_obj_t *parent) {
  lv_obj_t *dot = lv_obj_create(parent);
  lv_obj_remove_style_all(dot);
  lv_obj_set_size(dot, 10, 10);
  lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(dot, COL_LABEL, 0);
  lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, 0);
  return dot;
}

static StatCard make_stat_card(lv_obj_t *parent, lv_coord_t x, lv_coord_t y,
                                lv_coord_t w, lv_coord_t h, const char *title) {
  StatCard c;
  c.box = lv_obj_create(parent);
  lv_obj_remove_style_all(c.box);
  lv_obj_add_style(c.box, &style_card, 0);
  lv_obj_set_size(c.box, w, h);
  lv_obj_set_pos(c.box, x, y);
  lv_obj_clear_flag(c.box, LV_OBJ_FLAG_SCROLLABLE);

  lv_obj_t *lbl_title = lv_label_create(c.box);
  lv_label_set_text(lbl_title, title);
  lv_obj_set_style_text_color(lbl_title, COL_LABEL, 0);
  lv_obj_set_style_text_font(lbl_title, &lv_font_montserrat_14, 0);
  lv_obj_align(lbl_title, LV_ALIGN_TOP_LEFT, 0, 0);

  c.value = lv_label_create(c.box);
  lv_label_set_text(c.value, "--");
  lv_obj_set_style_text_color(c.value, COL_TEXT, 0);
  lv_obj_set_style_text_font(c.value, &lv_font_montserrat_20, 0);
  lv_obj_align(c.value, LV_ALIGN_BOTTOM_LEFT, 0, 0);
  return c;
}

static void build_ui() {
  lv_obj_t *scr = lv_scr_act();
  lv_obj_set_style_bg_color(scr, COL_BG, 0);
  lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);

  // Header
  lv_obj_t *title = lv_label_create(scr);
  lv_label_set_text(title, "ESP32-NUT | UPS TELEMETRY");
  lv_obj_set_style_text_color(title, COL_CYAN, 0);
  lv_obj_set_style_text_font(title, &lv_font_montserrat_14, 0);
  lv_obj_align(title, LV_ALIGN_TOP_LEFT, 6, 6);

  dot_live = make_dot(scr);
  lv_obj_align(dot_live, LV_ALIGN_TOP_RIGHT, -8, 8);

  // Status band
  lv_obj_t *status_box = lv_obj_create(scr);
  lv_obj_remove_style_all(status_box);
  lv_obj_add_style(status_box, &style_card, 0);
  lv_obj_set_size(status_box, LCD_H_RES - 12, 54);
  lv_obj_set_pos(status_box, 6, 28);
  lv_obj_clear_flag(status_box, LV_OBJ_FLAG_SCROLLABLE);

  lv_obj_t *status_title = lv_label_create(status_box);
  lv_label_set_text(status_title, "UPS STATUS");
  lv_obj_set_style_text_color(status_title, COL_LABEL, 0);
  lv_obj_set_style_text_font(status_title, &lv_font_montserrat_14, 0);
  lv_obj_align(status_title, LV_ALIGN_TOP_LEFT, 0, 0);

  lbl_status_value = lv_label_create(status_box);
  lv_label_set_text(lbl_status_value, "--");
  lv_obj_set_style_text_color(lbl_status_value, COL_TEXT, 0);
  lv_obj_set_style_text_font(lbl_status_value, &lv_font_montserrat_32, 0);
  lv_obj_align(lbl_status_value, LV_ALIGN_BOTTOM_LEFT, 0, 0);

  // 2x2 metric grid
  const lv_coord_t gx = 6, gy = 88, gap = 6;
  const lv_coord_t gw = (LCD_H_RES - gx * 2 - gap) / 2;
  const lv_coord_t gh = 50;

  card_batt = make_stat_card(scr, gx, gy, gw, gh, "BATTERY CHARGE");
  card_load = make_stat_card(scr, gx + gw + gap, gy, gw, gh, "UPS LOAD");
  card_runtime = make_stat_card(scr, gx, gy + gh + gap, gw, gh, "RUNTIME");
  card_power = make_stat_card(scr, gx + gw + gap, gy + gh + gap, gw, gh, "REAL POWER");

  // Footer: Wi-Fi + UPS connection lines
  dot_wifi = make_dot(scr);
  lv_obj_align(dot_wifi, LV_ALIGN_TOP_LEFT, 8, 202);
  lbl_wifi = lv_label_create(scr);
  lv_label_set_text(lbl_wifi, "Wi-Fi: --");
  lv_obj_set_style_text_color(lbl_wifi, COL_LABEL, 0);
  lv_obj_set_style_text_font(lbl_wifi, &lv_font_montserrat_14, 0);
  lv_obj_align(lbl_wifi, LV_ALIGN_TOP_LEFT, 22, 200);

  dot_ups = make_dot(scr);
  lv_obj_align(dot_ups, LV_ALIGN_TOP_LEFT, 8, 220);
  lbl_ups = lv_label_create(scr);
  lv_label_set_text(lbl_ups, "UPS: --");
  lv_obj_set_style_text_color(lbl_ups, COL_LABEL, 0);
  lv_obj_set_style_text_font(lbl_ups, &lv_font_montserrat_14, 0);
  lv_obj_align(lbl_ups, LV_ALIGN_TOP_LEFT, 22, 218);
}

static void set_dot_color(lv_obj_t *dot, lv_color_t c) {
  lv_obj_set_style_bg_color(dot, c, 0);
}

// Mirrors UPSData::computeUPSStatusString()'s flag codes (see
// esp32-nut: lib/USBHostUPS/src/UPSData.h) to color the status text.
static lv_color_t status_color(const String &s) {
  if (s.indexOf("LB") >= 0 || s.indexOf("FSD") >= 0 || s.indexOf("COMM_LOST") >= 0) return COL_RED;
  if (s.indexOf("OB") >= 0 || s.indexOf("OVER") >= 0 || s.indexOf("RB") >= 0) return COL_AMBER;
  if (s.indexOf("OL") >= 0) return COL_GREEN;
  return COL_LABEL;
}

static String format_runtime(long sec) {
  if (sec < 0) return "--";
  long m = sec / 60;
  long h = m / 60;
  m = m % 60;
  char buf[16];
  if (h > 0)
    snprintf(buf, sizeof(buf), "%ldh%02ldm", h, m);
  else
    snprintf(buf, sizeof(buf), "%ldm", m);
  return String(buf);
}

// ---------------------------------------------------------------------
// esp32-nut API client
// ---------------------------------------------------------------------
struct UpsSnapshot {
  bool disconnected = true;
  String status = "Unknown";
  bool hasBattery = false;
  float batteryCharge = 0;
  bool hasLoad = false;
  float upsLoad = 0;
  bool hasRuntime = false;
  long runtimeSec = -1;
  bool hasPower = false;
  float realPower = 0;
};

struct SystemInfo {
  String wifiStatus = "--";
  String upsModel = "--";
};

static bool httpGet(const String &path, String &payloadOut) {
  if (WiFi.status() != WL_CONNECTED) return false;

  HTTPClient http;
  String url = String("http://") + NUT_HOST + path;
  http.setTimeout(HTTP_TIMEOUT_MS);
  if (!http.begin(url)) return false;

  int code = http.GET();
  bool ok = (code == HTTP_CODE_OK);
  if (ok) payloadOut = http.getString();
  http.end();
  return ok;
}

static bool fetchUpsVars(UpsSnapshot &out) {
  String payload;
  if (!httpGet("/api/ups-vars", payload)) return false;

  JsonDocument doc;
  if (deserializeJson(doc, payload)) return false;

  out = UpsSnapshot();

  if (!doc["_disconnected"].isNull() && doc["_disconnected"].as<bool>()) {
    out.disconnected = true;
    out.status = "Disconnected";
    return true;
  }
  out.disconnected = false;

  if (!doc["ups.status"].isNull()) out.status = doc["ups.status"].as<String>();

  if (!doc["battery.charge"].isNull()) {
    out.hasBattery = true;
    out.batteryCharge = doc["battery.charge"].as<float>();
  }
  if (!doc["ups.load"].isNull()) {
    out.hasLoad = true;
    out.upsLoad = doc["ups.load"].as<float>();
  }
  if (!doc["battery.runtime"].isNull()) {
    out.hasRuntime = true;
    out.runtimeSec = doc["battery.runtime"].as<long>();
  }
  if (!doc["ups.realpower"].isNull()) {
    out.hasPower = true;
    out.realPower = doc["ups.realpower"].as<float>();
  } else if (!doc["ups.power"].isNull()) {
    out.hasPower = true;
    out.realPower = doc["ups.power"].as<float>();
  }
  return true;
}

static bool fetchSystemStatus(SystemInfo &out) {
  String payload;
  if (!httpGet("/api/system-status", payload)) return false;

  JsonDocument doc;
  if (deserializeJson(doc, payload)) return false;

  out.wifiStatus = doc["wifi"]["status"].as<String>();
  out.upsModel = doc["ups"]["status"].as<String>();
  return true;
}

// ---------------------------------------------------------------------
// UI update
// ---------------------------------------------------------------------
static void update_ups_ui(const UpsSnapshot &snap, bool fetchOk) {
  set_dot_color(dot_live, fetchOk ? COL_GREEN : COL_RED);

  if (!fetchOk) {
    lv_label_set_text(lbl_status_value, "NO LINK");
    lv_obj_set_style_text_color(lbl_status_value, COL_RED, 0);
    return;
  }

  if (snap.disconnected) {
    lv_label_set_text(lbl_status_value, "DISCONNECTED");
    lv_obj_set_style_text_color(lbl_status_value, COL_LABEL, 0);
    lv_label_set_text(card_batt.value, "--");
    lv_label_set_text(card_load.value, "--");
    lv_label_set_text(card_runtime.value, "--");
    lv_label_set_text(card_power.value, "--");
    return;
  }

  lv_label_set_text(lbl_status_value, snap.status.c_str());
  lv_obj_set_style_text_color(lbl_status_value, status_color(snap.status), 0);

  char buf[16];

  if (snap.hasBattery) {
    snprintf(buf, sizeof(buf), "%d%%", (int)roundf(snap.batteryCharge));
    lv_label_set_text(card_batt.value, buf);
  } else {
    lv_label_set_text(card_batt.value, "--");
  }

  if (snap.hasLoad) {
    snprintf(buf, sizeof(buf), "%d%%", (int)roundf(snap.upsLoad));
    lv_label_set_text(card_load.value, buf);
  } else {
    lv_label_set_text(card_load.value, "--");
  }

  lv_label_set_text(card_runtime.value,
                     snap.hasRuntime ? format_runtime(snap.runtimeSec).c_str() : "--");

  if (snap.hasPower) {
    snprintf(buf, sizeof(buf), "%dW", (int)roundf(snap.realPower));
    lv_label_set_text(card_power.value, buf);
  } else {
    lv_label_set_text(card_power.value, "--");
  }
}

static void update_system_ui(const SystemInfo &info, bool fetchOk) {
  if (!fetchOk) return; // keep last known values on a transient miss

  String wtxt = "Wi-Fi: " + info.wifiStatus;
  lv_label_set_text(lbl_wifi, wtxt.c_str());
  set_dot_color(dot_wifi, info.wifiStatus.indexOf("AP Mode") >= 0 ? COL_AMBER : COL_GREEN);

  String utxt = "UPS: " + info.upsModel;
  lv_label_set_text(lbl_ups, utxt.c_str());
  set_dot_color(dot_ups, info.upsModel == "Disconnected" ? COL_RED : COL_GREEN);
}

// ---------------------------------------------------------------------
// Wi-Fi
// ---------------------------------------------------------------------
static void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

// ---------------------------------------------------------------------
// Arduino entry points
// ---------------------------------------------------------------------
static uint32_t lastUpsPoll = 0;
static uint32_t lastStatusPoll = 0;
static uint32_t lastWifiAttempt = 0;

void setup() {
  Serial.begin(115200);

  pinMode(LCD_BACKLIGHT_PIN, OUTPUT);
  digitalWrite(LCD_BACKLIGHT_PIN, HIGH);

  gfx.init();
  gfx.fillScreen(TFT_BLACK);

  lv_init();

  size_t bufBytes = sizeof(lv_color_t) * LCD_H_RES * LCD_V_RES;
  lv_buf1 = (lv_color_t *)heap_caps_malloc(bufBytes, MALLOC_CAP_SPIRAM);
  lv_buf2 = (lv_color_t *)heap_caps_malloc(bufBytes, MALLOC_CAP_SPIRAM);
  if (!lv_buf1 || !lv_buf2) {
    Serial.println("FATAL: could not allocate LVGL draw buffers in PSRAM");
  }
  lv_disp_draw_buf_init(&draw_buf, lv_buf1, lv_buf2, LCD_H_RES * LCD_V_RES);

  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = LCD_H_RES;
  disp_drv.ver_res = LCD_V_RES;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  init_styles();
  build_ui();

  connectWiFi();
}

void loop() {
  lv_timer_handler();
  delay(5);

  uint32_t now = millis();

  if (touchForceRefresh) {
    touchForceRefresh = false;
    lastUpsPoll = 0;
    lastStatusPoll = 0;
  }

  if (WiFi.status() != WL_CONNECTED) {
    set_dot_color(dot_live, COL_RED);
    set_dot_color(dot_wifi, COL_RED);
    if (now - lastWifiAttempt >= WIFI_RETRY_INTERVAL_MS) {
      lastWifiAttempt = now;
      connectWiFi();
    }
    return;
  }

  if (lastUpsPoll == 0 || now - lastUpsPoll >= POLL_INTERVAL_MS) {
    lastUpsPoll = now;
    UpsSnapshot snap;
    bool ok = fetchUpsVars(snap);
    update_ups_ui(snap, ok);
  }

  if (lastStatusPoll == 0 || now - lastStatusPoll >= STATUS_POLL_INTERVAL_MS) {
    lastStatusPoll = now;
    SystemInfo info;
    bool ok = fetchSystemStatus(info);
    update_system_ui(info, ok);
  }
}
