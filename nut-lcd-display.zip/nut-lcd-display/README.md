# ESP32-NUT LCD Mirror

Mirrors the esp32-nut "UPS Telemetry" web dashboard onto a 320x240
Elecrow CrowPanel Advance 2.4" ESP32-S3 HMI display.

## Architecture: two separate boards, not a merge

This is firmware for a **second, independent ESP32-S3 board** — the
display — that talks to your existing esp32-nut device **over Wi-Fi**,
polling its existing read-only JSON API. It does **not** modify or
merge into the esp32-nut firmware, and it doesn't need to.

Why not put the display directly on the same board as the UPS bridge?

- esp32-nut's `esp32-s3-standard` build target is a generic
  `esp32-s3-devkitc-1` and depends on native USB-OTG **Host** wiring
  (the "bridge the USB-OTG pads" hardware mod described in its README)
  to talk to the UPS over USB.
- The CrowPanel Advance 2.4"'s USB-C port is used for
  programming/power, and Elecrow's own pin tables for this board don't
  expose the ESP32-S3's USB D+/D- lines for host mode — it's built as
  a display/HMI board, not a USB host board.

Combining both roles on one physical board isn't a firmware change,
it's a different, unsupported hardware wiring. Two boards on the same
Wi-Fi network — one doing UPS/USB work, one showing the dashboard — is
the straightforward, supported path.

## What it shows

Polls two endpoints already exposed by esp32-nut
(`src/network/web_config_server.cpp`), no server-side changes needed:

- `GET /api/ups-vars` (every 2s) — UPS status code, battery charge %,
  load %, runtime, real power.
- `GET /api/system-status` (every 10s) — Wi-Fi status, UPS model name.

The status text is colored using the same flag codes esp32-nut computes
in `UPSData::computeUPSStatusString()` (OL=green, OB/OVER/RB=amber,
LB/FSD/COMM_LOST=red). Tap the screen to force an immediate refresh.

## Before you build

Edit these three lines at the top of `src/main.cpp`:

```cpp
static const char *WIFI_SSID = "YOUR_WIFI_SSID";
static const char *WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
static const char *NUT_HOST = "192.168.1.50";   // your esp32-nut's IP
```

Find the esp32-nut IP from its own web UI footer or your router's
client list — it doesn't currently advertise mDNS, so a `.local` name
won't resolve unless you set that up yourself.

## Building

```
pio run -e elecrow-advance-2_4 -t upload
```

Board settings (already in `platformio.ini`) match Elecrow's documented
Arduino IDE settings for this board: 16MB flash, Octal PSRAM, "Huge
APP" partition scheme.

## Hardware reference used

Pin mapping (SPI ST7789 panel + I2C FT6336 touch + backlight GPIO) was
taken directly from Elecrow's official factory source for this exact
board/version, not guessed:
https://github.com/Elecrow-RD/CrowPanel-Advance-2.4-HMI-ESP32-320x240
(`factory_sourcecode/HMI2-4/LovyanGFX_Driver.h`).

## Known limitations / things you may want to tweak

- **Fonts**: the web UI uses "Orbitron"/"Share Tech Mono"; this sketch
  uses LVGL's built-in Montserrat fonts so it compiles with zero extra
  steps. For the exact look, convert those fonts with LVGL's [font
  converter](https://lvgl.io/tools/fontconverter) and swap the
  `lv_font_montserrat_*` references in `src/main.cpp`.
- **Polling is blocking**: each `HTTPClient` GET briefly blocks
  `loop()` (bounded by the 3s timeout), which pauses LVGL redraws for
  that moment. Fine for a status dashboard; if you add heavier
  animations later, move the HTTP calls to a separate FreeRTOS task.
- **No auth**: matches esp32-nut, whose GET endpoints are open on the
  local network — nothing extra to configure here, but be aware of it.
- I wrote and reviewed this in a sandbox without the ESP32 toolchain
  available, so it hasn't been hardware-compiled. If PlatformIO throws
  errors, paste them back and I'll fix them.
